 
/*****************************************************************************************
 * @file  TestTupleGenerator.java
 *
 * @author   John Miller
 */

import java.util.Random;

import static java.lang.System.out;

/*****************************************************************************************
 * This class tests the TupleGenerator on the Student Registration Database defined in the
 * Kifer, Bernstein and Lewis 2006 database textbook (see figure 3.6).  The primary keys
 * (see figure 3.6) and foreign keys (see example 3.2.2) are as given in the textbook.
 */
public class TestTupleGenerator
{
    /*************************************************************************************
     * The main method is the driver for TestGenerator.
     * @param args  the command-line arguments
     */
    public static void main (String [] args)
    {
        var test = new TupleGeneratorImpl ();

        test.addRelSchema ("Student",
                           "id name address status",
                           "Integer String String String",
                           "id",
                           null);
        
        test.addRelSchema ("Professor",
                           "id name deptId",
                           "Integer String String",
                           "id",
                           null);
        
        test.addRelSchema ("Course",
                           "crsCode deptId crsName descr",
                           "String String String String",
                           "crsCode",
                           null);
        
        test.addRelSchema ("Teaching",
                           "crsCode semester profId",
                           "String String Integer",
                           "crcCode semester",
                           new String [][] {{ "profId", "Professor", "id" },
                                            { "crsCode", "Course", "crsCode" }});
        
        test.addRelSchema ("Transcript",
                           "studId crsCode semester grade",
                           "Integer String String String",
                           "studId crsCode semester",
                           new String [][] {{ "studId", "Student", "id"},
                                            { "crsCode", "Course", "crsCode" },
                                            { "crsCode semester", "Teaching", "crsCode semester" }});

        var tables = new String [] { "Student", "Professor", "Course", "Teaching", "Transcript" };

        int tups [] = new int [] { 4000, 200, 300, 100, 3480};

        double sumJoin = 0;
        double sumselect = 0;
        double sumJoin2 = 0;
        double sumselect2 = 0;
       


        for (int i = 0; i < 20; i++) {
            Comparable[][][] resultTest = test.generate(tups);


            String student = "id name address status";
            String domain = "Integer String String String";

            String transAttr = "studId crsCode semester grade";
            String transDom = "Integer String String String";

            Table table1 = new Table("Student", student, domain, "id");
            Table table2 = new Table("Transcript", transAttr, transDom, "studId");

            //inserts each tuple into the table
            for (int k = 0; k < resultTest[0].length; k++) {
                table1.insert(resultTest[0][k]);
            }

            for (int x = 0; x < resultTest[4].length; x++) {
                table2.insert(resultTest[4][x]);
            }

//join
            long begintime = System.nanoTime();    
            Table result1 = table1.join("id", "studId", table2);
            long endTime = System.nanoTime();
            result1.print();
            sumJoin = (sumJoin + (endTime - begintime));
            System.out.println("run time join: " + (endTime - begintime));
        
            
//select
            long begintime2 = System.nanoTime();
           Table result2 = table1.select(new KeyType(543594));
            long endTime2 = System.nanoTime();           
            result2.print();
            sumselect = (sumselect + (endTime2 - begintime2));
            System.out.println("run time select: " + (endTime2 - begintime2));
        
            

 //for non index  start
   /*       
//non index join
long begintime3 = System.nanoTime();    
Table result3 = table1.nonindexjoin("id", "studId", table2);
long endTime3 = System.nanoTime();
result3.print();
sumJoin2 = (sumJoin2 + (endTime3- begintime3));
System.out.println("run time non index join: " + (endTime3 - begintime3));

//non index select
long begintime4 = System.nanoTime();
Table result4 = table1.nonindexselect(new KeyType(543594));
long endTime4 = System.nanoTime();

result4.print();
sumselect2 = (sumselect2 + (endTime4 - begintime4));
System.out.println("run time non index select: " + (endTime4 - begintime4));
*/

//for nonindex  end

 }
 
         System.out.println("Join  avg rt: " + sumJoin / 20);
         System.out.println("select  avg rt: " + sumselect / 20);
      
// for nonindex 
/* 
        System.out.println("Join  avg rt: " + sumJoin2 / 20);
        System.out.println("select  avg rt: " + sumselect2 / 20);
*/

 }     // main

} // TestTupleGenerator

