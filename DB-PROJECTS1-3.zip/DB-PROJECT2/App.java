import java.sql.*;
public class App {
    public static void main(String[] args) throws Exception
     {
             
            try
            {  
                Class.forName("com.mysql.cj.jdbc.Driver");  
                Connection conn=DriverManager.getConnection(  
                "jdbc:mysql://localhost:3306/employees","root","");  
                Statement stmt = conn.createStatement();

                 //query 1
                
                 String query1 = "SELECT dept_name, AVG(CASE when employees.gender='F' then salaries.Salary end) / AVG(CASE when employees.gender='M' then salaries.Salary end) AS avg_sal \r\n"
                 + "FROM departments join dept_emp join (employees join salaries) on departments.dept_no = dept_emp.dept_no and dept_emp.emp_no = employees.emp_no and employees.emp_no = salaries.emp_no\r\n"
                 + "GROUP BY dept_name\r\n"
                 + "order by avg_sal desc";
                 ResultSet rs1=stmt.executeQuery(query1);  
                 System.out.println("\n");
                 System.out.println("********query 1 output**********");
                 System.out.println("\n");
                 System.out.println("DEPARTMENT"+"                       "+"MAXFEMALE-RATIO");
                 while(rs1.next())  
                 { 
                 System.out.println(rs1.getString(1)+"                    "+rs1.getFloat(2));  
                 }
                 System.out.println("********query 1 output END**********");
                 System.out.println("\n");

                 //query 2
                 String query2 = "select d.*, datediff(case when to_date = '9999-01-01' then current_date else to_date end, from_date) as longest_duration from dept_emp d where datediff(case when to_date = '9999-01-01' then current_date else to_date end, from_date) = (select max(datediff(case when to_date = '9999-01-01' then current_date else to_date end,from_date)) from dept_emp)";
                 ResultSet rs2=stmt.executeQuery(query2);  
                 System.out.println("********query 2 output**********");
                 System.out.println("\n");
                 System.out.println("EMP_NO"+"   "+"DEPT_NO"+"    "+"FROM_DATE"+"   "+"TO_DATE"+"     "+"LONGEST_DURATION");
                 while(rs2.next())  
                 { 
                 System.out.println(rs2.getInt(1)+"     "+rs2.getString(2)+"    "+rs2.getDate(3)+ "   "+rs2.getDate(4)+ "   "+rs2.getInt(5));  
                 }
                 System.out.println("********query 2 output END**********");
                 System.out.println("\n");
              
                //query 3
                String query3 = "SELECT DISTINCT d.dept_name, AVG(s.salary), ROUND(YEAR(e.birth_date), -1), COUNT(*) FROM employees e, departments d, salaries s, dept_emp de WHERE de.emp_no = e.emp_no AND de.dept_no = d.dept_no AND e.emp_no = s.emp_no GROUP BY d.dept_name, ROUND(YEAR(e.birth_date), -1)";
                ResultSet rs3=stmt.executeQuery(query3);  
                System.out.println("********query 3 output**********");
                System.out.println("\n");
                System.out.println("DEPT_NAME"+"        "+"AVG_SALARY"+"    "+"YEAR"+"  "+"COUNT");
                while(rs3.next())  
                { 
                System.out.println(rs3.getString(1)+"    "+rs3.getInt(2)+"      "+rs3.getInt(3)+ "  "+rs3.getInt(4));  
                }
                System.out.println("********query 3 output END**********");
                System.out.println("\n");

                //query 4
                String query4 = "SELECT e.emp_no, e.first_name, e.last_name, e.birth_date, e.gender, s.salary FROM employees e, salaries s, dept_manager dm WHERE e.birth_date <= '1990-01-01' AND e.gender = 'F' AND s.salary > 80000 AND e.emp_no=dm.emp_no LIMIT 100";
                ResultSet rs4=stmt.executeQuery(query4);  
                System.out.println("********query 4 output**********");
                System.out.println("\n");
                System.out.println("EMP_NO"+"     "+"F_NAME"+"    "+"L_NAME"+"   "+"DOB"+"      "+"GENDER"+"   "+"SALARY");
                while(rs4.next())  
                { 
                System.out.println(rs4.getInt(1)+"    "+rs4.getString(2)+"  "+rs4.getString(3)+ "  "+rs4.getDate(4) + "   "+rs4.getString(5) + "    "+rs4.getInt(6));  
                } 
                System.out.println("********query 4 output END**********");
                System.out.println("\n");

                 //query 5
                 String query5 = "select distinct dept_emp.emp_no as E1, dept_emp.dept_no as D1, dept2.emp_no as E2 from dept_emp, (select * from dept_emp) as dept2   where dept_emp.emp_no != dept2.emp_no and dept_emp.dept_no = dept2.dept_no and dept_emp.from_date=dept2.from_date limit 100";
                 ResultSet rs5=stmt.executeQuery(query5);  
                 System.out.println("********query 5 output**********");
                 System.out.println("\n");
                System.out.println(" E1"+"       "+"D1"+"   "+"E2");
                 while(rs5.next())  
                 { 
                 System.out.println(rs5.getInt(1)+"  "+rs5.getString(2)+"  "+rs5.getInt(3));  
                 }
                 System.out.println("********query 5 output END**********");
                 System.out.println("\n");

                 //query 6
                 String query6 = "select e1 as 'E1' ,d1 as 'D1' ,e2 as 'E2',dept_no as 'D2',emp_no as 'E3' from (select * from (select emp_no as 'e1', dept_no as 'd1', from_date as 'f1' from dept_emp) as t1, (select emp_no as 'e2', dept_no as 'd2', from_date as 'f2' from dept_emp) as t2,(select emp_no as 'e3', dept_no as 'd3', from_date as 'f3' from dept_emp) as t3 where e1!=e2 and d1=d2 and e1!=e3 and d2!=d3 and e2=e3 ) as DEP1 inner join dept_emp on dept_emp.dept_no=DEP1.d3 where DEP1.f1=DEP1.f2 and DEP1.f2=DEP1.f3 and DEP1.f3=from_date limit 100";
                 ResultSet rs6=stmt.executeQuery(query6);  
                 System.out.println("********query 6 output**********");
                 System.out.println("\n");
                System.out.println("E1"+"     "+"D1"+"     "+"E2"+"     "+"D2"+"     "+"E3");
                 while(rs6.next())  
                 { 
                 System.out.println(rs6.getInt(1)+"  "+rs6.getString(2)+"  "+rs6.getInt(3)+ "  "+rs6.getString(4) + "  " + rs6.getInt(5));  
                 }
                 System.out.println("********query 6 output END**********");


                conn.close();  
            } catch(Exception e){ System.out.println(e);
            }  
     }  
}